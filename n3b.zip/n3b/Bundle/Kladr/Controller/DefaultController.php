<?php

/**
 * Created by PhpStorm.
 * User: alex
 * Date: 02.04.14
 * Time: 01:11
 */

namespace n3b\Bundle\Kladr\Controller;

use Exception;

use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

class DefaultController extends Controller
{

    /**
     * @Route("/moscow", name="kladr_moscow")
     *
     * @throws NotFoundHttpException
     * @Template()
     */

    public function moscowAction()
    {
      $ymaps_key = $this->container->getParameter('ymaps_key');
     // var_dump($ymaps_key);exit;

      return array('ymaps_key'=>$ymaps_key);
    }

    /**
     * @Route("/polygon/street", name="polygon_street")
     *
     * @throws NotFoundHttpException
     * @Template()
     */

    public function getPolygonStreetAction(Request  $request)
    {
      //$polygon_points = $request->
      $ymaps_key = $this->container->getParameter('ymaps_key');
     // var_dump($ymaps_key);exit;

      return array('ymaps_key'=>$ymaps_key);
    }

    /**
     * @Route("/", name="homepage")
     *
     * @throws NotFoundHttpException
     * @Template()
     */

    public function indexAction()
    {
      $ymaps_key = $this->container->getParameter('ymaps_key');
     // var_dump($ymaps_key);exit;

      return array('ymaps_key'=>$ymaps_key);
    }
}
