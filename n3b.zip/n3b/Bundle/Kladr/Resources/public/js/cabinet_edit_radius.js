function radiusRow(body){
	this.body = body;
	this.init();
}
extend(radiusRow, baseObject);
radiusRow.prototype.body = null;
radiusRow.prototype.map = null;
radiusRow.prototype.circle = null;
radiusRow.prototype.radius = null;
radiusRow.prototype.supplierMark = null;
radiusRow.prototype.polygon = null;
radiusRow.prototype.isOpen = false;
radiusRow.prototype.getDefaultName = function(){
	var index = $('.b-admin-radius__section').index(this.body[0]);
	return 'Район ' + (index+1);
};
radiusRow.prototype.init = function(){
	var _this = this;

	if (!this.getTitle()) {
		this.setTitle(this.getDefaultName());
	}

	this.body.find('a.del').click(function(e){
		return _this.onDelLinkClick(e);
	});

	this.getTitleTag().click(function(e){
		return _this.onTitleClick(e);
	});

    this.body.find('.show_street').click(function(){
        return _this.getPolygonStreet(e);
    });

};
radiusRow.prototype.getPolygonStreet = function(e){

}
radiusRow.prototype.onDelLinkClick = function(e){
	var el = $(e.currentTarget);
	cabinet.deleteObject('deliveryRadius', this.getId(), this.body);
	return false;
}
radiusRow.prototype.closeForm = function(){
	this.getFormContainer().hide();
	this.getTitleTag().find('i').removeClass('b-icon_toggle_act');
	this.showHeaderInfo(true);
}
radiusRow.prototype.showForm = function(){
	this.getFormContainer().show();
	this.getTitleTag().find('i').addClass('b-icon_toggle_act');
}
radiusRow.prototype.onCancelClick = function(e) {
	this.closeForm();
}
radiusRow.prototype.updateFromResponseData = function(data) {
	this.setTitle(data.name);
	this.setPrice(data.shipping_price);
	this.setId(data.id);
	this.getHeaderInfo().find('.min-amount').text(data.min_amount);
	this.getHeaderInfo().find('.delivery-time').text(data.delivery_time);
}
radiusRow.prototype.getTitle = function(){
	return $.trim(this.getTitleTag().find('.text').text());
}
radiusRow.prototype.setTitle = function(title) {
	if (!title) {
		title = this.getDefaultName();
	}
	this.getTitleTag().find('.text').text(title);
}
radiusRow.prototype.setPrice = function(price) {
	this.body.find('span.price>span').text(price);
}
radiusRow.prototype.setId = function(id) {
	this.body.data('id', id);
}
radiusRow.prototype.updateBounds = function(){
	var polygon;
	if (this.getTypeSelect().val() == 'radius') {
		polygon = this.circle;
	} else {
		polygon = this.polygon;
	}
	var bounds = this.getPolygonBounds(polygon);

	var form = this.getFormContainer();
	form.find('.min_lng').val(bounds.minLng);
	form.find('.min_lat').val(bounds.minLat);
	form.find('.max_lng').val(bounds.maxLng);
	form.find('.max_lat').val(bounds.maxLat);
}
radiusRow.prototype.saveForm = function(callback) {
	var form = this.getFormContainer().find('form');
	$.ajax({
		'type': 'POST',
		'url': form.attr('action'),
		'data': form.serialize(),
		'success': callback
	});
}
radiusRow.prototype.onFormSubmit = function(form){
	//this.updateBounds();
	var _this = this;
	this.saveForm(function(data, textStatus, jqXHR){
		if (isJsonResponse(jqXHR)) {
			_this.updateFromResponseData(data);
			_this.closeForm();
			return false;
		} else {
			form.replaceWith($(data));
			_this.initForm();
		}
	});
	return false;
};
radiusRow.prototype.onShowAllLinkClick = function(link){
	var addressesList = this.getFormContainer().find('.addresses-list');
	$.ajax({
		'type': 'POST',
		'url': baseUrl+'/cabinet/getDeliveryAddressesByRadius',
		'data': {'id':this.body.data('id')},
		'success': function(data){
			addressesList.text(data);
		},
		'loaderTarget' : addressesList
	});
	return false;
}

radiusRow.prototype.initForm = function(){
	var _this = this;
	/*$(this.getFormContainer().find('.prices input').get(0)).click(function(){
		_this.getFormContainer().find('.min-amount input').focus().select();
	});

	var nameInput = this.getFormContainer().find('[name$=\\[name\\]]');
	nameInput.attr('placeholder', this.getDefaultName());
	//addPlaceholderBehaviour(nameInput);

	this.body.find('.show-all').click(this.createEventHandler(this.onShowAllLinkClick));

	this.showHeaderInfo(false);
	this.getFormContainer().find('a.cancel').click(function(e){
		return _this.onCancelClick(e);
	});
	this.getFormContainer().find('.b-input-number').each(function(){
		new inputNumber($(this));
	});
	this.getFormContainer().find('form').submit(this.createEventHandler(this.onFormSubmit));
	*/

	this.map = new YMaps.Map(this.body.find('.map'));
	var centerPoint = new YMaps.GeoPoint(supplier.longitude, supplier.latitude);
	this.map.setCenter(centerPoint, 11);
	this.map.addControl(new YMaps.SmallZoom());
	this.map.addControl(new YMaps.ToolBar());

	this.getRadiusInput().change(function(e){
		_this.onRadiusChange();
	})

	this.body.find('.b-input-number .b-icon_minus, .b-input-number .b-icon_plus').click(function(e){
		_this.onRadiusChange();
	})
	this.getMinAmountInput().keyup(function(){
		_this.onMinAmountChange();
	});
	this.getTypeSelect().change(function(){
		_this.onTypeChange();
	});
	this.onTypeChange();
	this.showSupplierMark();
	this.getFormContainer().find('.edit-addresses-link').click(this.createEventHandler(this.onEditAddressesLinkClick));
}
radiusRow.prototype.getForm = function(){
	return this.getFormContainer().find('form');
}
radiusRow.prototype.onEditAddressesLinkClick = function(link){
	var _this = this;
	var goToAddresses = function(id){
		new ajaxLoader();
		window.location = baseUrl + '/cabinet/showDeliveryAddresses/radius/'+id;
	}
	if (!formIsDirty(this.getForm().get(0))) {
		goToAddresses(this.body.data('id'));
		return false;
	}
	var form = this.getForm();
	this.saveForm(function(data, textStatus, jqXHR){
		if (isJsonResponse(jqXHR)) {
			goToAddresses(data.id);
			return false;
		} else {
			form.replaceWith($(data));
			_this.initForm();
		}
	});

	return false;
}
radiusRow.prototype.showSupplierMark = function(){
	this.supplierMark = new YMaps.Placemark(new YMaps.GeoPoint(supplier.longitude, supplier.latitude), {
		style : {
			iconStyle : {
				href : "/img/admin_address_head.png",
				size : new YMaps.Point(18, 18),
				offset : new YMaps.Point(-9, -9)
			}
		},
		draggable : false,
		hasBalloon : false
		//hasHint : true
	});
	this.map.addOverlay(this.supplierMark);
}
radiusRow.prototype.showRadius = function(){
	var centerPoint = new YMaps.GeoPoint(supplier.longitude, supplier.latitude);
    this.circle = new Circle2(centerPoint, 0,{
        style : {
            polygonStyle : {
                outline : true,
                strokeWidth : 3,
                strokeColor : "00336655",
                fillColor : "00999933"
            }
        },
        interactive : YMaps.Interactivity.NONE
    });
    this.map.addOverlay(this.circle);
	this.map.setCenter(centerPoint);
	this.setRadius(this.getRadiusInput().val());
}
radiusRow.prototype.hideRadius = function(){
	this.map.removeOverlay(this.circle);
	//this.map.removeOverlay(this.supplierMark);
}
radiusRow.prototype.showPolygon = function(){
	var _this = this;
	// Создание стиля для многоугольника
	var style = new YMaps.Style("default#greenPoint");
	style.polygonStyle = new YMaps.PolygonStyle();
	style.polygonStyle.fill = 1;
	style.polygonStyle.outline = 1;
	style.polygonStyle.strokeWidth = 3;
	style.polygonStyle.strokeColor = "00336655";
	style.polygonStyle.fillColor = "00999933";
	YMaps.Styles.add("polygon#Example", style);

	var points = $.parseJSON(this.getPolygonPointsInput().val());
	if (points == 'null') {
		points = null;
	}

	if (points) {
		for (var i=0; i < points.length; i++) {
			points[i] = new YMaps.GeoPoint(points[i][0], points[i][1]);
		}
	} else {
		var distance = 0.05;
		points = [
		new YMaps.GeoPoint(parseFloat(supplier.longitude)-distance, parseFloat(supplier.latitude)-distance/1.5),
		new YMaps.GeoPoint(parseFloat(supplier.longitude)-distance, parseFloat(supplier.latitude)+distance/1.5),
		new YMaps.GeoPoint(parseFloat(supplier.longitude)+distance, parseFloat(supplier.latitude)+distance/1.5),
		new YMaps.GeoPoint(parseFloat(supplier.longitude)+distance, parseFloat(supplier.latitude)-distance/1.5)
		];
	}
console.log(points)
	// Создание многоугольника и добавление его на карту
	this.polygon = new YMaps.Polygon(points, {style: "polygon#Example", 'draggable': true});
	this.map.addOverlay(this.polygon);
	this.polygon.startEditing();

	this.map.setBounds(this.getPolygonGeoBounds(this.polygon));

	YMaps.Events.observe(this.polygon, this.polygon.Events.PositionChange, function () {
		_this.onPolygonPositionChange();
	});
	
}
radiusRow.prototype.getPolygonGeoBounds = function(polygon) {
	var bounds = this.getPolygonBounds(polygon);
	return new YMaps.GeoBounds(
		new YMaps.GeoPoint(bounds.minLng, bounds.minLat),
		new YMaps.GeoPoint(bounds.maxLng, bounds.maxLat)
	);
}
radiusRow.prototype.getPolygonBounds = function(polygon) {
	var points = polygon.getPoints();
	var lngs=[], lats=[];
	$.each(points, function(){
		lngs.push(this.getLng());
		lats.push(this.getLat());
	});
	return {
		minLng :  Math.min.apply(Math, lngs),
		maxLng :  Math.max.apply(Math, lngs),
		minLat :  Math.min.apply(Math, lats),
		maxLat :  Math.max.apply(Math, lats)
	};
}
radiusRow.prototype.getPolygonPointsInput = function(){
	return this.body.find('.polygon-points');
}
radiusRow.prototype.onPolygonPositionChange = function(){
	var points = this.polygon.getPoints();
	var point;
	var jsonParts = [];
	while (point = points.shift()) {
		jsonParts.push('['+point.getLng()+','+point.getLat()+']');
	}
	this.getPolygonPointsInput().val('['+jsonParts.join(',')+']');
}
radiusRow.prototype.hidePolygon = function(){
	this.map.removeOverlay(this.polygon);
}
radiusRow.prototype.getTypeSelect = function(){
	return this.getFormContainer().find('.type select');
}
radiusRow.prototype.getRadius = function(){
	return this.getFormContainer().find('.radius');
}
radiusRow.prototype.onTypeChange = function(){
	var addressesContainer = this.getFormContainer().find('.addresses');
	var mapContainer = this.getFormContainer().find('.map');
	if (this.getTypeSelect().val() == 'addresses') {
		addressesContainer.show();
		mapContainer.hide();
		this.getRadius().hide();
	} else {
		addressesContainer.hide();
		mapContainer.show();
		if (this.getTypeSelect().val()=='radius') {
			this.getRadius().show();
			this.showRadius();
			this.hidePolygon();
		} else {
			this.getRadius().hide();
			this.hideRadius();
			this.showPolygon();
		}
	}

}
radiusRow.prototype.onMinAmountChange = function(){
	this.getFormContainer().find('.prices input').first().val(this.getMinAmountInput().val());
};
radiusRow.prototype.getMinAmountInput = function(){
	return this.getFormContainer().find('.min-amount input');
};
radiusRow.prototype.getRadiusInput = function(){
	return this.body.find('.b-input-number input');
}

radiusRow.prototype.onRadiusChange = function(){
	this.setRadius(this.getRadiusInput().val());
}

radiusRow.prototype.setRadius = function(radius) {
    this.circle.setRadius(radius);
	var zoom;
	if (radius > 70) {
		zoom = 8
	} else if (radius > 30) {
		zoom = 9
	} else if (radius > 15) {
		zoom = 10
	} else if (radius > 8) {
		zoom = 11
	} else {
		zoom = 12
	}
	this.map.setZoom(zoom, {'smooth':true});
}

radiusRow.prototype.openForm = function(){
	this.getFormContainer().show();
	this.loadForm();
}
radiusRow.prototype.loadForm = function(){
	var _this = this;
	this.getFormContainer().load(
		baseUrl+'cabinet/editRadius/id/'+this.getId(),
		function(){_this.initForm();}
	);

}
radiusRow.prototype.onTitleClick = function(e){
	var el = $(e.currentTarget)
	el.children('i').toggleClass('b-icon_toggle_act');
	
	var sectionBody = el.closest('div.b-admin-radius__section').children('div.b-admin-radius__section__body');
	sectionBody.toggle();

	if (this.getFormContainer().is(':visible')) {
console.log(1)
		this.loadForm();
	} else {
console.log(2)
		this.showHeaderInfo(true);
	}
	return false;
}
radiusRow.prototype.getTitleTag = function(){
	return this.body.find('h3.title');
}
radiusRow.prototype.getFormContainer = function(){
	return this.body.find('.b-admin-radius__section__body');
}
radiusRow.prototype.getHeaderInfo = function(){
	return this.body.find('.b-admin-radius__section__head .delivery, .b-admin-radius__section__head h3.title .text');
}
radiusRow.prototype.showHeaderInfo = function(show){
	var headerInfo = this.getHeaderInfo();
	if (show) {
		headerInfo.show();
	} else {
		headerInfo.hide();
	}
}
radiusRow.prototype.getId = function(){
	return this.body.data('id');
}


function radiusList(body){
	this.body = body;
	this.init();
}
extend(radiusList, baseObject);
radiusList.prototype.body = null;
radiusList.prototype.getRadiusToOpen = function(){
	var execResult = /openRadius([0-9]+)/.exec(window.location.hash);
	if (execResult) {
		return execResult[1];
	} else {
		return null;
	}
}
radiusList.prototype.init = function(){

	var radiusToOpen = this.getRadiusToOpen();
	
	this.body.find('.b-admin-radius__section').each(function(){
		var radius = new radiusRow($(this));
		if ($(this).data('id') == radiusToOpen) {
			radius.openForm();
			$(this).find('.b-icon_toggle').addClass('b-icon_toggle_act');
		}
        radius.initForm(this.body);
	});

	this.body.find('a.b-btn_plus').click(this.createEventHandler(this.onPlusClick));
}
radiusList.prototype.onPlusClick = function(link){
	var radiusBody = $('.hiddenRadiusRow').children('div').clone();
	//radiusBody.insertBefore(link.parent('div'));
	radiusBody.appendTo(this.body.find('.b-admin-radius__body'));
//	radiusBody.find('.title').click(function(){
//		var $this = $(this);
//		$this.children('i').toggleClass('b-icon_toggle_act');
//		$this.closest('div.b-admin-radius__section').children('div.b-admin-radius__section__body').toggle();
//	});
	var row = new radiusRow(radiusBody);
    row.showForm();
    row.loadForm();
	return false;
}

$(function(){

	new radiusList($('.b-admin-radius'));

});
