<?php

namespace n3b\Bundle\Kladr;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class n3bKladrBundle extends Bundle
{
}
